import React from "react";
import { Badge } from "reactstrap";
import "../assets/_common.scss";
import Activities from "./Activities";
import ActivityLog from "./ActivityLog";
import Assigned from "./AssignTo";
import Demo from "./Demo";
import Flags from "./Flags";
import Notes from "./Notes";
import Tasks from "./Tasks";
import EmailDetails from "./EmailDetails";
import Alert from "./Alert";
import Equipments from "./Equipments";
import Todo from "./Todo";
import Docs from "./Docs";
import Checkin from "./Checkin";
export default function Main() {
  return (
    <div className="bg-color-body">
      <div className="bg-color-content">
      
        <Badge className="mr-2 p-2" color="primary">Demo</Badge>
        <Badge color="warning p-2">Haze</Badge>
        <Demo/>
        <Flags/>
        <Tasks/>
        <Activities/>
        <Assigned/>
        <ActivityLog/>
        <Notes/>
        <EmailDetails/>
        <Alert/>
        <Equipments/>
        <Todo/>
        <Docs/>
        <Checkin/>
      </div>
    </div>
  );
}
