import React, { useEffect, useState } from "react";
import { Button, Col, Row, Table } from "reactstrap";
import { AiOutlineDown, AiOutlineUp, AiOutlineEdit, AiOutlineDelete } from "react-icons/ai";
import moment from "moment";

export default function Tasks() {
  const [data, setData] = useState([]);
  const [isOpen, setIsOpen] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await fetch("https://jsonplaceholder.typicode.com/users/");
      const jsonData = await response.json();
      setData(jsonData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleToggle = () => {
    setIsOpen(!isOpen);
  };

  const handleEdit = (item) => {
    // Perform edit functionality with the item
    console.log("Edit item:", item);
  };

  const handleDelete = (item) => {
    // Perform delete functionality with the item
    console.log("Delete item:", item);
  };

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const formatDate = (date) => {
    return moment(date).format("MM/DD/YYYY");
  };

  const renderTableData = () => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const paginatedData = data.slice(startIndex, endIndex);

    if (paginatedData.length === 0) {
      return (
        <tr>
          <td colSpan="9" className="text-center">
            No data to show
          </td>
        </tr>
      );
    }

    return paginatedData.map((item, index) => (
      <tr key={index}>
        <td>{item.id}</td>
        <td>{item.status}</td>
        <td>{item.title}</td>
        <td>{item.assignedTo}</td>
        <td>{formatDate(item.scheduleStart)}</td>
        <td>{formatDate(item.workStart)}</td>
        <td>{formatDate(item.workStop)}</td>
        <td>{formatDate(item.dueDate)}</td>
        <td className="text-right">
          <Button color="primary" size="sm" onClick={() => handleEdit(item)}>
            <AiOutlineEdit />
          </Button>{" "}
          <Button color="danger" size="sm" onClick={() => handleDelete(item)}>
            <AiOutlineDelete />
          </Button>
        </td>
      </tr>
    ));
  };

  const renderPagination = () => {
    const totalPages = Math.ceil(data.length / itemsPerPage);

    if (totalPages <= 1) {
      return null;
    }

    return (
      <div className="d-flex justify-content-center mt-4">
        <nav>
          <ul className="pagination">
            {Array.from({ length: totalPages }, (_, index) => (
              <li key={index} className={`page-item ${currentPage === index + 1 ? "active" : ""}`}>
                <button className="page-link" onClick={() => handlePageChange(index + 1)}>
                  {index + 1}
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    );
  };

  return (
    <div className="m-4">
      <Row className="mb-4 align-items-center">
        <Col>
          <h5>
            <strong>Tasks</strong>
          </h5>
        </Col>
        <Col className="text-right">
          <Button color="info" size="md" onClick={handleToggle}>
            {isOpen ? <AiOutlineUp /> : <AiOutlineDown />}
          </Button>
          <Button className="ml-2" color="info" size="md">
            Add Task
          </Button>
        </Col>
      </Row>

      {isOpen && (
        <>
          <Table responsive className="table-striped">
            <thead>
              <tr>
                <th>Id</th>
                <th>Status</th>
                <th>Title</th>
                <th>Assigned To</th>
                <th>Schedule Start</th>
                <th>Work Start</th>
                <th>Work Stop</th>
                <th>Due Date</th>
                <th className="text-right">Actions</th>
              </tr>
            </thead>
            <tbody>{renderTableData()}</tbody>
          </Table>
          {renderPagination()}
        </>
      )}

      {!isOpen && <hr />} {/* Add hr when the table is closed */}
    </div>
  );
}
