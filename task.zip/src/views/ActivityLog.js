import React, { useState } from "react";
import { Button, Card, CardContent, CardHeader, Container, Grid, Typography } from "@mui/material";
import { CheckCircle } from "@mui/icons-material";
import moment from "moment";

export default function Dashboard() {
  const [task, setTask] = useState({
    id: 1,
    name: "Task Name",
    stages: [
      {
        id: 1,
        name: "Initialized",
        date: moment().subtract(7, "days").format("MM/DD/YYYY"),
        completed: true,
      },
      // ...rest of the stages
    ],
  });

  const handleStageClick = (stageId) => {
    const updatedTask = { ...task };
    const stageIndex = updatedTask.stages.findIndex((stage) => stage.id === stageId);
    if (stageIndex !== -1) {
      updatedTask.stages[stageIndex].completed = true;
      setTask(updatedTask);
    }
  };

  const renderStages = () => {
    return task.stages.map((stage) => (
      <Grid item xs={12} sm={6} md={4} lg={3} key={stage.id}>
        <Card className={`stage-card ${stage.completed ? "completed" : ""}`}>
          <CardHeader
            title={stage.name}
            titleTypographyProps={{ variant: "h6" }}
            action={stage.completed && <CheckCircle className="stage-icon" />}
          />
          <CardContent>
            <Typography variant="body2">
              <strong>Date:</strong> {stage.date}
            </Typography>
            {!stage.completed && (
              <Button variant="contained" color="primary" size="small" onClick={() => handleStageClick(stage.id)}>
                Mark as Completed
              </Button>
            )}
          </CardContent>
        </Card>
      </Grid>
    ));
  };

  return (
    <div className="m-4">
      <Container>
        <Typography variant="h5" component="h2" gutterBottom>
          Task Dashboard - {task.name}
        </Typography>
        <Grid container spacing={3}>
          {renderStages()}
        </Grid>
      </Container>
    </div>
  );
}
