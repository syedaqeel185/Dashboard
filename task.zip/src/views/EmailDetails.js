import React, { useEffect, useState } from "react";
import { Button, Col, Row, Table } from "reactstrap";
import { AiOutlineDown, AiOutlineUp, AiOutlineEdit, AiOutlineDelete } from "react-icons/ai";

export default function EmailDetails() {
  const [data, setData] = useState([]);
  const [isOpen, setIsOpen] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await fetch("https://jsonplaceholder.typicode.com/users/");
      const jsonData = await response.json();
      setData(jsonData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleToggle = () => {
    setIsOpen(!isOpen);
  };

  const handleEdit = (item) => {
    // Perform edit functionality with the item
    console.log("Edit item:", item);
  };

  const handleDelete = (item) => {
    // Perform delete functionality with the item
    console.log("Delete item:", item);
  };

  return (
    <div className="m-4">
      <Row className="mb-4 align-items-center">
        <Col>
          <h5>
            <strong>Email Details</strong>
          </h5>
        </Col>
        <Col className="text-right">
          <Button color="info" size="md" onClick={handleToggle}>
            {isOpen ? <AiOutlineUp /> : <AiOutlineDown />}
          </Button>
          <Button className="ml-2" color="info" size="md">
            Add Email
          </Button>
        </Col>
      </Row>

      {isOpen ? (
        <Table responsive className="table-striped">
          <thead>
            <tr>
              <th>Date</th>
              <th>From</th>
              <th>To</th>
              <th>CC</th>
              <th className="text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {data.map((item, index) => (
              <tr key={index}>
                <td>{item.date}</td>
                <td>{item.from}</td>
                <td>{item.to}</td>
                <td>{item.cc}</td>
                <td className="text-right">
                  <Button color="primary" size="sm" onClick={() => handleEdit(item)}>
                    <AiOutlineEdit />
                  </Button>{" "}
                  <Button color="danger" size="sm" onClick={() => handleDelete(item)}>
                    <AiOutlineDelete />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      ) : (
        <hr className="my-4" />
      )}

      {data.length <= 0 && <div className="m-3 text-center">No Records Found</div>}
    </div>
  );
}
