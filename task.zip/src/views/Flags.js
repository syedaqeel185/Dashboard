import React, { useEffect, useState } from "react";
import { Button, Col, Row, Table } from "reactstrap";
import { AiOutlineEdit, AiOutlineDelete, AiOutlineDown, AiOutlineUp } from "react-icons/ai";

export default function Flags() {
  const [data, setData] = useState([]);
  const [isOpen, setIsOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await fetch("https://jsonplaceholder.typicode.com/users/");
      const jsonData = await response.json();
      setData(jsonData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleToggle = () => {
    setIsOpen(!isOpen);
  };

  const handleEdit = (item) => {
    // Perform edit functionality with the item
    console.log("Edit item:", item);
  };

  const handleDelete = (item) => {
    // Perform delete functionality with the item
    console.log("Delete item:", item);
  };

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = data.slice(indexOfFirstItem, indexOfLastItem);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  return (
    <div className="m-4">
      <Row className="mb-4 align-items-center">
        <Col>
          <h5>
            <strong>Flags</strong>
          </h5>
        </Col>
        <Col className="text-right">
          <Button color="info" size="md" onClick={handleToggle}>
            {isOpen ? <AiOutlineUp /> : <AiOutlineDown />}
          </Button>
          <Button color="info" size="md" className="ml-2">
            Add Flag
          </Button>
        </Col>
      </Row>

      {isOpen ? (
        <Table responsive className="table-striped">
          <thead>
            <tr>
              <th>Name</th>
              <th className="text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {currentItems.length > 0 ? (
              currentItems.map((item) => (
                <tr key={item.id}>
                  <td>{item.name}</td>
                  <td className="text-right">
                    <Button color="primary" size="sm" onClick={() => handleEdit(item)}>
                      <AiOutlineEdit />
                    </Button>{" "}
                    <Button color="danger" size="sm" onClick={() => handleDelete(item)}>
                      <AiOutlineDelete />
                    </Button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="2" className="text-center">
                  No data available
                </td>
              </tr>
            )}
          </tbody>
        </Table>
      ) : (
        <hr className="my-4" />
      )}

      {data.length === 0 && !isOpen && (
        <div className="text-center mt-4">No data available</div>
      )}

      {data.length > itemsPerPage && isOpen && (
        <nav>
          <ul className="pagination justify-content-center">
            {Array(Math.ceil(data.length / itemsPerPage))
              .fill()
              .map((_, index) => (
                <li
                  key={index}
                  className={`page-item ${currentPage === index + 1 ? "active" : ""}`}
                >
                  <Button className="page-link" onClick={() => handlePageChange(index + 1)}>
                    {index + 1}
                  </Button>
                </li>
              ))}
          </ul>
        </nav>
      )}
    </div>
  );
}
