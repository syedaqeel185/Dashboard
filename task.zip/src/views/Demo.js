import React from "react";
import { Col, Row } from "reactstrap";
import {
  FiFlag,
  FiClock,
  FiUserCheck,
  FiUsers,
  FiCalendar,
  FiCheckSquare,
  FiUserPlus,
  FiClipboard,
  FiMapPin,
  FiHome,
  FiLayers,
  FiPhone,
  FiMail,
  FiPhoneCall,
  FiUser,
  FiDollarSign,
} from "react-icons/fi";

export default function ProjectDashboard() {
  return (
    <div className="m-4">
      <Row>
        <Col>
          <h2 className="text-primary mb-4">Project Details</h2>
        </Col>
      </Row>

      <Row>
        <Col xs={12} sm={6} md={3}>
          <div className="dashboard-card bg-light p-4 rounded">
            <div className="d-flex align-items-center mb-3">
              <FiClipboard size={30} className="mr-2" />
              <h4 className="mb-0">PO Number</h4>
            </div>
            <p className="text-muted mb-0">PO-12345</p>
          </div>
        </Col>
        <Col xs={12} sm={6} md={3}>
          <div className="dashboard-card bg-light p-4 rounded">
            <div className="d-flex align-items-center mb-3">
              <FiMapPin size={30} className="mr-2" />
              <h4 className="mb-0">Location</h4>
            </div>
            <p className="text-muted mb-0">123 Main St, City</p>
          </div>
        </Col>
        <Col xs={12} sm={6} md={3}>
          <div className="dashboard-card bg-light p-4 rounded">
            <div className="d-flex align-items-center mb-3">
              <FiHome size={30} className="mr-2" />
              <h4 className="mb-0">Address</h4>
            </div>
            <p className="text-muted mb-0">456 Secondary St, City</p>
          </div>
        </Col>
        <Col xs={12} sm={6} md={3}>
          <div className="dashboard-card bg-light p-4 rounded">
            <div className="d-flex align-items-center mb-3">
              <FiLayers size={30} className="mr-2" />
              <h4 className="mb-0">Property Overflow</h4>
            </div>
            <p className="text-muted mb-0">Yes</p>
          </div>
        </Col>
      </Row>

      <Row className="mt-4">
        <Col xs={12} sm={6} md={3}>
          <div className="dashboard-card bg-light p-4 rounded">
            <div className="d-flex align-items-center mb-3">
              <FiCalendar size={30} className="mr-2" />
              <h4 className="mb-0">Scheduled To</h4>
            </div>
            <p className="text-muted mb-0">John Doe</p>
          </div>
        </Col>
        <Col xs={12} sm={6} md={3}>
          <div className="dashboard-card bg-light p-4 rounded">
            <div className="d-flex align-items-center mb-3">
              <FiPhone size={30} className="mr-2" />
              <h4 className="mb-0">Contact</h4>
            </div>
            <p className="text-muted mb-0">123-456-7890</p>
          </div>
        </Col>
        <Col xs={12} sm={6} md={3}>
          <div className="dashboard-card bg-light p-4 rounded">
            <div className="d-flex align-items-center mb-3">
              <FiMail size={30} className="mr-2" />
              <h4 className="mb-0">Email</h4>
            </div>
            <p className="text-muted mb-0">johndoe@example.com</p>
          </div>
        </Col>
        <Col xs={12} sm={6} md={3}>
          <div className="dashboard-card bg-light p-4 rounded">
            <div className="d-flex align-items-center mb-3">
              <FiPhoneCall size={30} className="mr-2" />
              <h4 className="mb-0">Phone Number</h4>
            </div>
            <p className="text-muted mb-0">987-654-3210</p>
          </div>
        </Col>
      </Row>

      <Row className="mt-4">
        <Col xs={12} sm={6} md={3}>
          <div className="dashboard-card bg-light p-4 rounded">
            <div className="d-flex align-items-center mb-3">
              <FiClock size={30} className="mr-2" />
              <h4 className="mb-0">Work Start</h4>
            </div>
            <p className="text-muted mb-0">09:00 AM</p>
          </div>
        </Col>
        <Col xs={12} sm={6} md={3}>
          <div className="dashboard-card bg-light p-4 rounded">
            <div className="d-flex align-items-center mb-3">
              <FiClock size={30} className="mr-2" />
              <h4 className="mb-0">Work Stop</h4>
            </div>
            <p className="text-muted mb-0">05:00 PM</p>
          </div>
        </Col>
        <Col xs={12} sm={6} md={3}>
          <div className="dashboard-card bg-light p-4 rounded">
            <div className="d-flex align-items-center mb-3">
              <FiCalendar size={30} className="mr-2" />
              <h4 className="mb-0">Created On</h4>
            </div>
            <p className="text-muted mb-0">2023-06-16</p>
          </div>
        </Col>
        <Col xs={12} sm={6} md={3}>
          <div className="dashboard-card bg-light p-4 rounded">
            <div className="d-flex align-items-center mb-3">
              <FiUser size={30} className="mr-2" />
              <h4 className="mb-0">Created By</h4>
            </div>
            <p className="text-muted mb-0">Jane Smith</p>
          </div>
        </Col>
      </Row>

      <Row className="mt-4">
        <Col xs={12} sm={6} md={3}>
          <div className="dashboard-card bg-light p-4 rounded">
            <div className="d-flex align-items-center mb-3">
              <FiUserCheck size={30} className="mr-2" />
              <h4 className="mb-0">Bill To</h4>
            </div>
            <p className="text-muted mb-0">ABC Company</p>
          </div>
        </Col>
        <Col xs={12} sm={6} md={3}>
          <div className="dashboard-card bg-light p-4 rounded">
            <div className="d-flex align-items-center mb-3">
              <FiDollarSign size={30} className="mr-2" />
              <h4 className="mb-0">Estimate Total</h4>
            </div>
            <p className="text-muted mb-0">$5000</p>
          </div>
        </Col>
      </Row>

      <Row className="mt-5">
        <Col>
          <h2 className="text-primary mb-4">Scheduling and Assignment</h2>
        </Col>
      </Row>

      <Row>
        <Col xs={12} sm={6} md={3}>
          <div className="dashboard-card bg-light p-4 rounded">
            <div className="d-flex align-items-center mb-3">
              <FiFlag size={30} className="mr-2" />
              <h4 className="mb-0">Priority</h4>
            </div>
            <p className="text-muted mb-0">High</p>
          </div>
        </Col>
        <Col xs={12} sm={6} md={3}>
          <div className="dashboard-card bg-light p-4 rounded">
            <div className="d-flex align-items-center mb-3">
              <FiClock size={30} className="mr-2" />
              <h4 className="mb-0">Access/Appt/Start</h4>
            </div>
            <p className="text-muted mb-0">10:00 AM</p>
          </div>
        </Col>
        <Col xs={12} sm={6} md={3}>
          <div className="dashboard-card bg-light p-4 rounded">
            <div className="d-flex align-items-center mb-3">
              <FiUserCheck size={30} className="mr-2" />
              <h4 className="mb-0">On-Site By</h4>
            </div>
            <p className="text-muted mb-0">John Doe</p>
          </div>
        </Col>
        <Col xs={12} sm={6} md={3}>
          <div className="dashboard-card bg-light p-4 rounded">
            <div className="d-flex align-items-center mb-3">
              <FiUsers size={30} className="mr-2" />
              <h4 className="mb-0">Speciality</h4>
            </div>
            <p className="text-muted mb-0">Plumbing</p>
          </div>
        </Col>
      </Row>

      <Row className="mt-4">
        <Col xs={12} sm={6} md={3}>
          <div className="dashboard-card bg-light p-4 rounded">
            <div className="d-flex align-items-center mb-3">
              <FiClock size={30} className="mr-2" />
              <h4 className="mb-0">Duration</h4>
            </div>
            <p className="text-muted mb-0">2 hours</p>
          </div>
        </Col>
        <Col xs={12} sm={6} md={3}>
          <div className="dashboard-card bg-light p-4 rounded">
            <div className="d-flex align-items-center mb-3">
              <FiCalendar size={30} className="mr-2" />
              <h4 className="mb-0">Assigned On</h4>
            </div>
            <p className="text-muted mb-0">2023-06-15</p>
          </div>
        </Col>
        <Col xs={12} sm={6} md={3}>
          <div className="dashboard-card bg-light p-4 rounded">
            <div className="d-flex align-items-center mb-3">
              <FiUserPlus size={30} className="mr-2" />
              <h4 className="mb-0">Assigned By</h4>
            </div>
            <p className="text-muted mb-0">Jane Smith</p>
          </div>
        </Col>
      </Row>
    </div>
  );
}
