import React, { useState, useEffect } from "react";
import { Button } from "reactstrap";
import "./table.scss";

const Table = (props) => {
  const {
    listItemToDisplay,
    textButtonsToDisplay,
    onTableButtonClick,
    data,
    noOfRecordsPerPageOptions = [5, 10, 20, 50],
    isCheckOption = false,
    onCheckOptionToggle,
    allChecked = false,
  } = props;

  const [filteredData, setFilteredData] = useState([]);
  const [noOfRecordPerPage, setNoOfRecordPerPage] = useState(10);
  const [listItemToPrint, setListItemToPrint] = useState([]);

  let currentStartingValue = 0;
  let isSortedAsscending = true;

  useEffect(() => {
    displayCurrentPageRecord(0, 10);
    const listItemToPrint = data.map((item) => {
      return listItemToDisplay.map((nes) => item[nes.valueField]);
    });
    setListItemToPrint(listItemToPrint);
  }, []);

  useEffect(() => {
    const listItemToPrint = data.map((item) => {
      return listItemToDisplay.map((nes) => item[nes.valueField]);
    });
    setListItemToPrint(listItemToPrint);
    displayCurrentPageRecord(0, 10);
  }, [data]);

  useEffect(() => {}, [data.length]);

  const displayCurrentPageRecord = (startFrom, noOfRecordPerPageValue) => {
    let noOfRecordPerPageVal;
    if (noOfRecordPerPageValue !== undefined) {
      noOfRecordPerPageVal = noOfRecordPerPageValue;
    } else {
      noOfRecordPerPageVal = noOfRecordPerPage;
    }
    currentStartingValue = startFrom;
    const items = data.slice(
      startFrom * noOfRecordPerPageVal,
      +noOfRecordPerPageVal + startFrom * +noOfRecordPerPageVal
    );
    setFilteredData(items);
  };

  return (
    <div className="table-wrapper">
      <div className="table-header"></div>
      <table className="table">
        <thead className="table-head">
          <tr>
            {isCheckOption && (
              <th>
                <input
                  type="checkbox"
                  checked={allChecked}
                  onClick={() => onCheckOptionToggle(null)}
                />
              </th>
            )}
            {listItemToDisplay.map((item) => (
              <th key={item.name}>{item.name}</th>
            ))}
            {textButtonsToDisplay && (
              <th className="actionHead text-center font-weight-bold">
                {textButtonsToDisplay.length > 0 ? "Action" : null}
              </th>
            )}
          </tr>
        </thead>
        <tbody className="table-body">
          {filteredData.map((item, index) => (
            <tr key={index}>
              {isCheckOption && (
                <td>
                  <input
                    type="checkbox"
                    checked={item.Checked}
                    onClick={() => onCheckOptionToggle(item)}
                  />
                </td>
              )}
              {listItemToDisplay.map((nes, index) => (
                <td key={index} data-label={nes.name}>{`${
                  item[nes.valueField] !== undefined ? item[nes.valueField] : ""
                }`}</td>
              ))}

              <td className="text-center">
                {textButtonsToDisplay &&
                  textButtonsToDisplay.map((btn, index) => (
                    <td key={index} className="img-btn-col">
                      <Button
                        onClick={() => onTableButtonClick(item, btn.name)}
                        color={btn.color}
                      >
                        {btn.buttonLabel}
                      </Button>
                    </td>
                  ))}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Table;
